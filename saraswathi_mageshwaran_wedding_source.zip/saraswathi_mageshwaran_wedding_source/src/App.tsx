import { useEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, Sparkles, Text3D, Center } from '@react-three/drei'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { gsap } from 'gsap'
import { CalendarDays, Check, Clock3, Copy, Heart, MapPin, Music2, Pause, Play, Share2, Volume2, VolumeX } from 'lucide-react'
import * as THREE from 'three'

const MAP_URL = 'https://maps.app.goo.gl/4vEB8Qayk87V58Q89'
const WEDDING_START = new Date('2026-11-20T09:00:00+05:30').getTime()
const WEDDING_END = new Date('2026-11-20T10:30:00+05:30').getTime()

function GoldHeart() {
  const ref = useRef<THREE.Mesh>(null!)
  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = Math.sin(clock.elapsedTime * 0.35) * 0.22
      ref.current.rotation.z = Math.sin(clock.elapsedTime * 0.22) * 0.06
    }
  })
  return <Float speed={1.2} rotationIntensity={0.15} floatIntensity={0.3}>
    <mesh ref={ref} scale={1.25}>
      <torusGeometry args={[0.72, 0.11, 16, 100]} />
      <meshStandardMaterial color="#d7b66e" metalness={0.82} roughness={0.22} />
    </mesh>
    <mesh position={[0, 0, 0.03]} scale={0.72}>
      <torusGeometry args={[0.72, 0.1, 16, 100]} />
      <meshStandardMaterial color="#f0dba4" metalness={0.72} roughness={0.2} />
    </mesh>
  </Float>
}

function ThreeOrnament() {
  const reduced = useReducedMotion()
  return <div className="three-wrap" aria-hidden="true">
    <Canvas camera={{ position: [0, 0, 4.4], fov: 40 }} dpr={[1, 1.5]}>
      <ambientLight intensity={1.2} />
      <pointLight position={[2, 3, 4]} intensity={35} color="#ffdf9a" />
      <pointLight position={[-3, -2, 2]} intensity={12} color="#a86b2c" />
      <GoldHeart />
      {!reduced && <Sparkles count={55} scale={4.5} size={2.2} speed={0.18} color="#f4d58c" />}
    </Canvas>
  </div>
}

function useCountdown() {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000)
    return () => window.clearInterval(id)
  }, [])
  return useMemo(() => {
    const distance = Math.max(0, WEDDING_START - now)
    return {
      complete: distance === 0,
      days: Math.floor(distance / 86400000),
      hours: Math.floor((distance % 86400000) / 3600000),
      minutes: Math.floor((distance % 3600000) / 60000),
      seconds: Math.floor((distance % 60000) / 1000)
    }
  }, [now])
}

function downloadCalendar() {
  const ics = [
    'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Saraswathi and Mageshwaran//Wedding//EN',
    'CALSCALE:GREGORIAN','BEGIN:VEVENT',
    'UID:saraswathi-mageshwaran-20261120@wedding',
    'DTSTAMP:20261021T000000Z','DTSTART:20261120T033000Z','DTEND:20261120T050000Z',
    'SUMMARY:Wedding of G. Saraswathi and P. Mageshwaran',
    'LOCATION:Veerabahu Mahal\\, North Authoor\\, Tamil Nadu 628151',
    'DESCRIPTION:Wedding ceremony. Directions: https://maps.app.goo.gl/4vEB8Qayk87V58Q89',
    'END:VEVENT','END:VCALENDAR'
  ].join('\r\n')
  const url = URL.createObjectURL(new Blob([ics], { type: 'text/calendar;charset=utf-8' }))
  const a = document.createElement('a'); a.href = url; a.download = 'saraswathi-mageshwaran-wedding.ics'; a.click()
  URL.revokeObjectURL(url)
}

function App() {
  const [opened, setOpened] = useState(false)
  const [music, setMusic] = useState(false)
  const [copied, setCopied] = useState(false)
  const [guestName, setGuestName] = useState('')
  const [guestCount, setGuestCount] = useState('2')
  const [attendance, setAttendance] = useState('yes')
  const [wishes, setWishes] = useState('')
  const [rsvpMessage, setRsvpMessage] = useState('')
  const mainRef = useRef<HTMLElement>(null)
  const countdown = useCountdown()
  const reducedMotion = useReducedMotion()

  useEffect(() => {
    if (opened && mainRef.current) {
      gsap.fromTo('.reveal', { y: 28, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, stagger: 0.09, ease: 'power3.out', clearProps: 'all' })
    }
  }, [opened])

  const shareText = 'You are warmly invited to the wedding of G. Saraswathi & P. Mageshwaran on Friday, 20 November 2026, from 9:00 AM to 10:30 AM at Veerabahu Mahal, North Authoor, Tamil Nadu. We would be delighted to celebrate this special day with you! Wedding Location: ' + MAP_URL
  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      setCopied(true); window.setTimeout(() => setCopied(false), 2200)
    } catch { window.prompt('Copy this invitation link:', window.location.href) }
  }
  const share = async () => {
    if (navigator.share) {
      try { await navigator.share({ title: 'Saraswathi ♥ Mageshwaran Wedding', text: shareText, url: window.location.href }) } catch { /* user cancelled */ }
    } else { await copyLink() }
  }
  const whatsapp = () => window.open('https://wa.me/?text=' + encodeURIComponent(shareText + '\n' + window.location.href), '_blank', 'noopener,noreferrer')
  const toggleMusic = () => {
    // Browsers block autoplay. This is a user-controlled visual music state;
    // add a licensed audio file in public/music.mp3 to enable actual music.
    setMusic(v => !v)
  }
  const submitRsvp = (e: React.FormEvent) => {
    e.preventDefault()
    if (!guestName.trim()) { setRsvpMessage('Please enter your name.'); return }
    // This demo intentionally does not pretend to send/store personal data.
    const result = `Thank you, ${guestName.trim()}! Your response is ready. This demo does not send or store RSVPs. Please contact the family directly to confirm.`
    setRsvpMessage(result)
  }

  return <>
    <AnimatePresence>
      {!opened && <motion.div className="intro" initial={{ opacity: 1 }} exit={{ opacity: 0, scale: 1.03 }} transition={{ duration: reducedMotion ? 0.1 : 0.8 }}>
        <div className="intro-grain" />
        <div className="envelope-scene">
          <motion.div className="envelope" animate={reducedMotion ? {} : { y: [0, -8, 0], rotateY: [0, 2, 0] }} transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}>
            <div className="envelope-flap" />
            <div className="envelope-seal"><Heart size={24} fill="currentColor" /></div>
            <div className="envelope-mark">S <span>♥</span> M</div>
            <div className="envelope-small">A WEDDING INVITATION</div>
          </motion.div>
        </div>
        <motion.p className="eyebrow" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>A CELEBRATION OF LOVE</motion.p>
        <motion.h1 initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}>You Are Cordially Invited</motion.h1>
        <p className="intro-names">G. Saraswathi <span>♥</span> P. Mageshwaran</p>
        <motion.button className="gold-button" onClick={() => setOpened(true)} whileHover={{ scale: 1.035 }} whileTap={{ scale: 0.98 }}>
          Open Our Wedding Invitation <span>↗</span>
        </motion.button>
        <p className="intro-date">FRIDAY · 20 NOVEMBER 2026</p>
      </motion.div>}
    </AnimatePresence>

    <header className="site-header">
      <a className="brand" href="#top" aria-label="Back to top">S <span>♥</span> M</a>
      <nav><a href="#families">Families</a><a href="#details">The Wedding</a><a href="#rsvp">Wishes</a></nav>
      <div className="header-actions">
        <button className="icon-button" onClick={toggleMusic} aria-label={music ? 'Mute music' : 'Enable music'} title="Music is a visual toggle until you add a licensed audio file">{music ? <Volume2 size={17}/> : <VolumeX size={17}/>}</button>
        <button className="icon-button" onClick={share} aria-label="Share invitation"><Share2 size={17}/></button>
      </div>
    </header>

    <main ref={mainRef} id="top">
      <section className="hero section-pad">
        <div className="hero-copy">
          <p className="eyebrow reveal">WITH JOY IN OUR HEARTS</p>
          <h1 className="hero-title reveal"><span>G. Saraswathi</span><i>&</i><span>P. Mageshwaran</span></h1>
          <p className="hero-quote reveal">“Two Hearts, Two Souls, One Love for All Time.”</p>
          <div className="hero-rule reveal"><span>✦</span></div>
          <p className="hero-date reveal">FRIDAY <b>·</b> 20 NOVEMBER 2026</p>
          <p className="hero-time reveal">9:00 AM — 10:30 AM</p>
          <button className="text-button reveal" onClick={() => document.getElementById('families')?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' })}>Explore Our Invitation <span>↓</span></button>
        </div>
        <ThreeOrnament />
        <div className="hero-corner top-left">❧</div><div className="hero-corner bottom-right">❧</div>
      </section>

      <section className="intro-message paper-section section-pad">
        <div className="ornament">✧ ❦ ✧</div>
        <p className="eyebrow">A DAY TO REMEMBER</p>
        <h2 className="section-title">A New Chapter Begins</h2>
        <p className="prose">Two hearts, two souls, one love for all time. It would give us great pleasure if you would join us on our wedding day and bless the beginning of our life together.</p>
        <div className="ornament">❦</div>
      </section>

      <section id="families" className="families-section section-pad">
        <div className="section-heading reveal"><p className="eyebrow">ROOTED IN LOVE</p><h2 className="section-title">Together With Our Families</h2><p className="muted">With the blessings and love of our families</p></div>
        <div className="family-grid">
          <motion.article className="family-card reveal" whileHover={reducedMotion ? {} : { y: -5 }}>
            <div className="family-icon"><Heart size={20}/></div><p className="eyebrow">THE BRIDE</p><h3>G. Saraswathi</h3>
            <div className="fine-rule" />
            <p>Mr. J. Gandhimathi Nathan</p><p>Mrs. G. Pooselvi</p>
          </motion.article>
          <div className="family-ampersand">♥</div>
          <motion.article className="family-card reveal" whileHover={reducedMotion ? {} : { y: -5 }}>
            <div className="family-icon"><Heart size={20}/></div><p className="eyebrow">THE GROOM</p><h3>P. Mageshwaran</h3>
            <div className="fine-rule" />
            <p>Mr. P. Prasanth</p><p>Mrs. P. Prema</p>
          </motion.article>
        </div>
        <p className="small-note">Please check family-name spellings against the original invitation before publishing.</p>
      </section>

      <section className="countdown-section section-pad">
        <p className="eyebrow">THE COUNTDOWN BEGINS</p>
        <h2 className="section-title">Until We Say “I Do”</h2>
        {countdown.complete ? <p className="countdown-done">Today is the day! Thank you for celebrating with us. ♥</p> :
          <div className="countdown-grid">{[['days',countdown.days],['hours',countdown.hours],['minutes',countdown.minutes],['seconds',countdown.seconds]].map(([label,value]) => <div className="count-unit" key={label}><strong>{String(value).padStart(2,'0')}</strong><span>{label}</span></div>)}</div>}
        <p className="save-date">SAVE THE DATE · 20.11.2026</p>
        <button className="outline-button" onClick={downloadCalendar}><CalendarDays size={17}/> Add to Calendar</button>
      </section>

      <section id="details" className="details-section paper-section section-pad">
        <div className="section-heading reveal"><p className="eyebrow">THE BEGINNING OF FOREVER</p><h2 className="section-title">The Wedding Ceremony</h2><p className="muted">We would be honoured by your presence and blessings.</p></div>
        <div className="event-card reveal">
          <div className="event-top"><span>✧</span><span className="eyebrow">WEDDING INVITATION</span><span>✧</span></div>
          <h3>G. Saraswathi <em>&</em> P. Mageshwaran</h3>
          <div className="event-detail"><CalendarDays/><div><span>DATE</span><p>Friday, 20 November 2026</p></div></div>
          <div className="event-detail"><Clock3/><div><span>MUHURTHAM / CEREMONY TIME</span><p>9:00 AM – 10:30 AM</p></div></div>
          <div className="event-detail"><MapPin/><div><span>VENUE</span><p>Veerabahu Mahal</p><small>North Authoor, Tamil Nadu – 628151</small></div></div>
          <a className="gold-button link-button" href={MAP_URL} target="_blank" rel="noreferrer"><MapPin size={17}/> Get Directions <span>↗</span></a>
          <button className="copy-venue" onClick={async () => { const text = 'Veerabahu Mahal, North Authoor, Tamil Nadu – 628151'; try { await navigator.clipboard.writeText(text); setCopied(true); window.setTimeout(() => setCopied(false), 2200) } catch { window.prompt('Copy venue details:', text) } }}><Copy size={15}/>{copied ? 'Copied!' : 'Copy Venue Details'}</button>
        </div>
      </section>

      <section className="journey-section section-pad">
        <div className="journey-heart"><Heart size={34}/></div>
        <p className="eyebrow">A PROMISE FOR TOMORROW</p>
        <h2 className="section-title">Two Hearts, One Beautiful Journey</h2>
        <p className="prose">Some journeys are written in the stars. Ours begins a beautiful new chapter on 20 November 2026.</p>
      </section>

      <section id="rsvp" className="rsvp-section section-pad">
        <div className="section-heading"><p className="eyebrow">YOUR BLESSINGS MEAN EVERYTHING</p><h2 className="section-title">Your Presence Will Make Our Day More Special</h2><p className="muted">Kindly let us know if you plan to join us.</p></div>
        <form className="rsvp-form" onSubmit={submitRsvp}>
          <label>Guest name<input value={guestName} onChange={e => setGuestName(e.target.value)} placeholder="Enter your name" required maxLength={100}/></label>
          <label>Number of guests<select value={guestCount} onChange={e => setGuestCount(e.target.value)}><option value="1">1 guest</option><option value="2">2 guests</option><option value="3">3 guests</option><option value="4">4 guests</option><option value="5">5 guests</option><option value="6+">6 or more</option></select></label>
          <fieldset><legend>Will you be attending?</legend><label className="radio-label"><input type="radio" name="attendance" value="yes" checked={attendance === 'yes'} onChange={e => setAttendance(e.target.value)}/> Joyfully accept</label><label className="radio-label"><input type="radio" name="attendance" value="no" checked={attendance === 'no'} onChange={e => setAttendance(e.target.value)}/> Regretfully decline</label></fieldset>
          <label>Wedding wishes (optional)<textarea value={wishes} onChange={e => setWishes(e.target.value)} placeholder="Write a blessing for the couple..." rows={3} maxLength={500}/></label>
          <button className="gold-button submit-button" type="submit"><Heart size={16}/> Send Response</button>
          {rsvpMessage && <p className="form-message" role="status"><Check size={16}/>{rsvpMessage}</p>}
          <p className="privacy-note">Demo form only: this page does not transmit or store RSVP details. Connect a secure form service or backend before collecting responses.</p>
        </form>
      </section>

      <section className="closing-section section-pad">
        <div className="closing-ornament">♡</div><p className="eyebrow">WITH LOVE & BLESSINGS</p>
        <h2 className="closing-title">G. Saraswathi <span>&</span><br/>P. Mageshwaran</h2>
        <p className="closing-date">20 NOVEMBER 2026 <span>·</span> 9:00 AM – 10:30 AM</p>
        <p className="closing-message">Your presence and blessings will make our special day unforgettable.</p>
        <div className="closing-rule">✧ ❦ ✧</div>
        <p className="compliments">With Best Compliments From Friends & Relatives.</p>
        <div className="share-actions"><button className="outline-button" onClick={share}><Share2 size={16}/> Share Invitation</button><button className="outline-button" onClick={whatsapp}><Heart size={16}/> WhatsApp</button><button className="outline-button" onClick={copyLink}><Copy size={16}/>{copied ? 'Copied!' : 'Copy Link'}</button></div>
      </section>
    </main>
    <footer><a className="brand" href="#top">S <span>♥</span> M</a><p>Made with love for a beautiful beginning.</p><button onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' })}>Back to top ↑</button></footer>
    <button className="floating-share" aria-label="Share wedding invitation" onClick={share}><Share2 size={19}/></button>
  </>
}

export default App
